from django.apps import AppConfig

class GolemConfig(AppConfig):
    name = 'golem'
